/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdlib.h>
#include "stdio.h"
#include "math.h"
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC1_MATRIX_SIZE 4
#define ADC2_MATRIX_SIZE 3
#define ADC3_MATRIX_SIZE 2
#define ADC1_PERIOD 0.000025
#define ADC2_PERIOD 0.000025
#define ADC3_PERIOD 0.000025
#define V_IN_MAX 300
#define V_IN_MIN -50
#define V_OUT_MAX 240
#define V_OUT_MIN -10
#define I_IN_MAX 20
#define I_IN_MIN -1
#define I_OUT_MAX 20
#define I_OUT_MIN -1
#define I_L_MAX 6
#define I_L_MIN -0.5
#define DUTY_CYCLE_MAX 85
#define DUTY_CYCLE_MIN 0
#define DUTY_CYCLE_STEP 0.25
#define KP 0.0005
#define KI 0.08
#define ALPHA 0.0005
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
ADC_HandleTypeDef hadc3;
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc2;
DMA_HandleTypeDef hdma_adc3;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim8;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
static uint16_t adc_1_raw_values[ADC1_MATRIX_SIZE]={0};
static uint16_t adc_2_raw_values[ADC2_MATRIX_SIZE]={0};
static uint16_t adc_3_raw_values[ADC3_MATRIX_SIZE]={0};

static float adc_1_cal_values[ADC1_MATRIX_SIZE]={0};
static float adc_2_cal_values[ADC2_MATRIX_SIZE]={0};
static float adc_3_cal_values[ADC3_MATRIX_SIZE]={0};

static float adc_1_filt_values[ADC1_MATRIX_SIZE]={0};
static float adc_2_filt_values[ADC2_MATRIX_SIZE]={0};
static float adc_3_filt_values[ADC3_MATRIX_SIZE]={0};

static float i_in_meas = 0;
static float i_l1_meas = 0;
static float i_l2_meas = 0;
static float i_l3_meas = 0;
static float i_l4_meas = 0;
static float i_out_meas = 0;
static float v_in_meas = 0;
static float v_out_meas = 0;
static uint8_t status = 0;
static uint8_t button_state = 1;
uint16_t FAULT = 0;
uint8_t previous_phases = 0;
uint8_t current_phases = 0;
static float duty_pot = 0;
static float duty_temp = 0;
static float duty_cycle = 0;
static float I = 0;
static float v_ref_pot = 0;
static float v_ref_user = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM8_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC2_Init(void);
static void MX_ADC1_Init(void);
static void MX_ADC3_Init(void);
static void MX_TIM6_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM5_Init(void);
/* USER CODE BEGIN PFP */
void off_state(void);
void fault_state(void);
void init_state(uint8_t *previous_phases, uint8_t *current_phases);
void init_adc_dma(void);
void control_loop(float v_in_meas , float v_out_meas , float i_in_meas , float i_out_meas , float i_l1_meas , float i_l2_meas , float i_l3_meas , float i_l4_meas , uint8_t *previous_phases , uint8_t *current_phases , float *duty_temp , float duty_pot , float *duty_cycle , float *I , float v_ref_pot, float *v_ref_user);
void safety_check(float v_in_meas , float v_out_meas , float i_in_meas , float i_out_meas , float i_l1_meas , float i_l2_meas , float i_l3_meas , float i_l4_meas);
void phase_control(float i_out_meas , uint8_t *previous_phases , uint8_t *current_phases);
void route_duty_cycle(float *duty_temp , float duty_pot , float *duty_cycle);
void voltage_control(float v_out_meas, float *duty_cycle , float *I , float duty_pot , float v_ref_pot, float *v_ref_user);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_TIM8_Init();
  MX_TIM3_Init();
  MX_ADC2_Init();
  MX_ADC1_Init();
  MX_ADC3_Init();
  MX_TIM6_Init();
  MX_TIM2_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T3_TRGO;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 4;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_14;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_10;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = ENABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc2.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T3_TRGO;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 3;
  hadc2.Init.DMAContinuousRequests = ENABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_15;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief ADC3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC3_Init(void)
{

  /* USER CODE BEGIN ADC3_Init 0 */

  /* USER CODE END ADC3_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC3_Init 1 */

  /* USER CODE END ADC3_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc3.Instance = ADC3;
  hadc3.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc3.Init.Resolution = ADC_RESOLUTION_12B;
  hadc3.Init.ScanConvMode = ENABLE;
  hadc3.Init.ContinuousConvMode = DISABLE;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc3.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T3_TRGO;
  hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc3.Init.NbrOfConversion = 2;
  hadc3.Init.DMAContinuousRequests = ENABLE;
  hadc3.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_13;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC3_Init 2 */

  /* USER CODE END ADC3_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 23;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 99;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_ENABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 50;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 11;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 99;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 33;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 89;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 49;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 11;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 99;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 33;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */
  HAL_TIM_MspPostInit(&htim5);

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 89;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 49999;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 23;
  htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim8.Init.Period = 99;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_ENABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 25;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim8, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */
  HAL_TIM_MspPostInit(&htim8);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
  /* DMA2_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream1_IRQn);
  /* DMA2_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* Start a timer when button is pressed -  For Debouncing*/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if(GPIO_Pin == B1_Pin && button_state == 1){
		HAL_TIM_Base_Start_IT(&htim6);
		button_state = 0;
	}
}

/*	STATUS TABLE
0 = OFF
1 = ON
*/

/* Change Status for the button after the press */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	if ( htim == &htim6 ) {
		button_state = 1;
		HAL_TIM_Base_Stop_IT(&htim6);
		if (status==1){
			status=0;
			off_state();
			return;
		}
		else if (status==0){
			status=1;
			init_state(&previous_phases , &current_phases);
			return;
		}
	}
}

/* Initialization - Starts after button is pressed */
void init_state(uint8_t *previous_phases, uint8_t *current_phases) {
	off_state();
	init_adc_dma();
	*previous_phases = 0;
	*current_phases = 0;
}

/* Initialize ADC modules and start timer 3 that controls ADC modules */
void init_adc_dma(void){
	HAL_TIM_Base_Start(&htim3);
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_1_raw_values, ADC1_MATRIX_SIZE);
	HAL_ADC_Start_DMA(&hadc2, (uint32_t*)adc_2_raw_values, ADC2_MATRIX_SIZE);
	HAL_ADC_Start_DMA(&hadc3, (uint32_t*)adc_3_raw_values, ADC3_MATRIX_SIZE);
}

/* Off state - All timers are stopped */
void off_state(void){
	HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_4);
	HAL_TIM_PWM_Stop(&htim8, TIM_CHANNEL_3);
	HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Stop(&htim5, TIM_CHANNEL_1);

	HAL_TIM_Base_Stop(&htim1);
	HAL_TIM_Base_Stop(&htim8);
	HAL_TIM_Base_Stop(&htim2);
	HAL_TIM_Base_Stop(&htim5);

	HAL_ADC_Stop_DMA(&hadc1);
	HAL_ADC_Stop_DMA(&hadc2);
	HAL_ADC_Stop_DMA(&hadc3);

	HAL_TIM_Base_Stop(&htim3);
}

/* Fault state - Stop everything - Requires the user to start the code again */
void fault_state(void){
	off_state();
	HAL_TIM_Base_Stop(&htim6);
	button_state = 0;
	while(0){
		__NOP();
	}
}

/* Read from the ADC modules, calibrate the values, filter the calibrated values
 * and then store the values correctly - After that start the control loop function
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc){
	if (hadc == &hadc1){
		adc_1_cal_values[0] = (adc_1_raw_values[0] * 0.001796f) + 0.077519f;
		adc_1_cal_values[1] = -(adc_1_raw_values[1] * 0.1069299f) + 267.24883f;
		adc_1_cal_values[2] = (adc_1_raw_values[2] * 0.0090349f) - 0.252534f;
		adc_1_cal_values[3] = (adc_1_raw_values[3] * 0.2442f);

		for (int i = 0; i < ADC1_MATRIX_SIZE; i++) {
			adc_1_filt_values[i] = ALPHA * adc_1_cal_values[i] + (1-ALPHA) * adc_1_filt_values[i];
		}

		i_l2_meas = adc_1_filt_values[0];
		v_in_meas = adc_1_filt_values[1];
		i_out_meas = adc_1_filt_values[2];
		duty_pot = adc_1_filt_values[3];
		v_ref_pot = adc_1_filt_values[3]/5;
	}

	if (hadc == &hadc2){
		adc_2_cal_values[0] = (adc_2_raw_values[0] * 0.009041f) - 0.202154f;
		adc_2_cal_values[1] = -(adc_2_raw_values[1] * 0.105397f) + 264.76684f;
		adc_2_cal_values[2] = (adc_2_raw_values[2] * 0.001783f) + 0.01618f;

		for (int i = 0; i < ADC2_MATRIX_SIZE; i++) {
			adc_2_filt_values[i] = ALPHA * adc_2_cal_values[i] + (1-ALPHA) * adc_2_filt_values[i];
		}

		i_in_meas = adc_2_filt_values[0];
		v_out_meas = adc_2_filt_values[1];
		i_l1_meas = adc_2_filt_values[2];
	}

	if (hadc == &hadc3){
		adc_3_cal_values[0] = (adc_3_raw_values[0] * 0.0017944f) - 0.1168217f;
		adc_3_cal_values[1] = (adc_3_raw_values[1] * 0.001771f) - 0.1225f;

		for (int i = 0; i < ADC3_MATRIX_SIZE; i++) {
			adc_3_filt_values[i] = ALPHA * adc_3_cal_values[i] + (1-ALPHA) * adc_3_filt_values[i];
		}

		i_l3_meas = adc_3_filt_values[0];
		i_l4_meas = adc_3_filt_values[1];
	}

	control_loop(v_in_meas , v_out_meas , i_in_meas , i_out_meas , i_l1_meas , i_l2_meas , i_l3_meas , i_l4_meas , &previous_phases , &current_phases, &duty_temp , duty_pot , &duty_cycle , &I , v_ref_pot , &v_ref_user);
}

/* Main control loop - Safety Check, calculate number of active phases based on output current
 * and then just route duty cycle for open loop  or voltage control for closed loop
 */
void control_loop( float v_in_meas , float v_out_meas , float i_in_meas , float i_out_meas , float i_l1_meas , float i_l2_meas , float i_l3_meas , float i_l4_meas , uint8_t *previous_phases , uint8_t *current_phases , float *duty_temp, float duty_pot, float *duty_cycle , float *I , float v_ref_pot, float *v_ref_user){
	safety_check(v_in_meas , v_out_meas , i_in_meas , i_out_meas , i_l1_meas , i_l2_meas , i_l3_meas , i_l4_meas);
	phase_control(i_out_meas , previous_phases , current_phases);
	float mode = 1;
	if (mode == 0){
		route_duty_cycle(duty_temp , duty_pot , duty_cycle);
	}
	if (mode == 1){
		voltage_control(v_out_meas, duty_cycle , I , duty_pot , v_ref_pot , v_ref_user);
	}
}


/*	FAULT CODES
1 = OUTPUT OVERVOLTAGE
2 = INPUT OVERVOLTAGE
3 = OUTPUT UNDERVOLTAGE
4 = INPUT UNDERVOLTAGE
5 = INDUCTOR 1 OVERCURRENT
6 = INDUCTOR 2 OVERCURRENT
7 = INDUCTOR 3 OVERCURRENT
8 = INDUCTOR 4 OVERCURRENT
9 = INDUCTOR 1 UNDERCURRENT
10 = INDUCTOR 2 UNDERCURRENT
11 = INDUCTOR 3 UNDERCURRENT
12 = INDUCTOR 4 UNDERCURRENT
13 = INPUT OVERCURRENT
14 = OUTPUT OVERCURRENT
15 = INPUT UNDERCURRENT
16 = OUTPUT UNDERCURRENT  	*/

/* Safety Check */
void safety_check( float v_in_meas , float v_out_meas , float i_in_meas , float i_out_meas , float i_l1_meas , float i_l2_meas , float i_l3_meas , float i_l4_meas ){

	if (v_in_meas > V_IN_MAX){
		FAULT = 1;
		fault_state();
	}

	if (v_out_meas > V_OUT_MAX){
		FAULT = 2;
		fault_state();
	}

	if (v_in_meas < V_IN_MIN){
		FAULT = 3;
		fault_state();
	}

	if (v_out_meas < V_OUT_MIN){
		FAULT = 4;
		fault_state();
	}

	if (i_l1_meas > I_L_MAX){
		FAULT = 5;
		fault_state();
	}

	if (i_l2_meas > I_L_MAX){
		FAULT = 6;
		fault_state();
	}

	if (i_l3_meas > I_L_MAX){
		FAULT = 7;
		fault_state();
	}

	if (i_l4_meas > I_L_MAX){
		FAULT = 8;
		fault_state();
	}

	if (i_l1_meas < I_L_MIN){
		FAULT = 9;
		fault_state();
	}

	if (i_l2_meas < I_L_MIN){
		FAULT = 10;
		fault_state();
	}

	if (i_l3_meas < I_L_MIN){
		FAULT = 11;
		fault_state();
	}

	if (i_l4_meas < I_L_MIN){
		FAULT = 12;
		fault_state();
	}

	if (i_in_meas > I_IN_MAX){
		FAULT = 13;
		fault_state();
	}

	if (i_out_meas > I_OUT_MAX){
		FAULT = 14;
		fault_state();
	}

	if (i_in_meas < I_IN_MIN){
		FAULT = 15;
		fault_state();
	}

	if (i_out_meas < I_OUT_MIN){
		FAULT = 16;
		fault_state();
	}
}

/* Phase control - Calculate number of active phases based on output current
 * Create the PWM signal for the MOSFETs
 * */
void phase_control( float i_out_meas, uint8_t *previous_phases, uint8_t *current_phases){
	*previous_phases = *current_phases;

	if (i_out_meas < 2.5) {
		*current_phases = 1;
		if (*previous_phases != *current_phases && *previous_phases == 0){
			HAL_TIM_Base_Start(&htim1);
			HAL_TIM_Base_Start(&htim8);
			HAL_TIM_Base_Start(&htim2);
			HAL_TIM_Base_Start(&htim5);
		}
		if (*previous_phases != *current_phases){
			HAL_TIM_PWM_Stop(&htim5, TIM_CHANNEL_1);
			HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
			HAL_TIM_PWM_Stop(&htim8, TIM_CHANNEL_3);
			HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
		}
	}

	if (i_out_meas > 3 && i_out_meas < 4) {
		*current_phases = 2;
		if (*previous_phases != *current_phases){
			HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
			HAL_TIM_PWM_Stop(&htim5, TIM_CHANNEL_1);
			HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_3);
			while (1){
				if (TIM1->CNT == 50){
					TIM8->CNT = 0;
					break;
				}
			}
		}
	}


	if (i_out_meas > 6 && i_out_meas < 7){
		*current_phases = 3;
		if (*previous_phases != *current_phases){
			HAL_TIM_PWM_Stop(&htim5 , TIM_CHANNEL_1);
			HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
			while(1){
				if (TIM1->CNT == 66){
					TIM2->CNT = 0;
					break;
				}
			}
			while(1){
				if (TIM1->CNT == 33){
					TIM8->CNT = 0;
					break;
				}
			}
		}
	}

	if (i_out_meas > 9) {
		*current_phases = 4;
		if (*previous_phases != *current_phases){
			HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_1);
			while(1){
				if (TIM1->CNT == 25){
					TIM2->CNT = 0;
					break;
				}
			}
			while(1){
				if (TIM1->CNT == 50){
					TIM8->CNT = 0;
					break;
				}
			}
			while(1){
				if (TIM1->CNT == 75){
					TIM5->CNT = 0;
					break;
				}
			}
		}
	}
}

/* Route duty cycle for open loop - First 9  lines of code are used to slow down the process */
void route_duty_cycle(float *duty_temp , float duty_pot , float *duty_cycle){
	if (*duty_temp < (100 * duty_pot)) {
		*duty_temp = *duty_temp + DUTY_CYCLE_STEP;
	}
	else if (*duty_temp > (100 * duty_pot)) {
		*duty_temp = *duty_temp - DUTY_CYCLE_STEP;
	}

	*duty_cycle = (*duty_temp)*1e-3;

	if (*duty_cycle > DUTY_CYCLE_MAX){
		*duty_cycle = DUTY_CYCLE_MAX;
	}
	if (*duty_cycle < DUTY_CYCLE_MIN){
		*duty_cycle = DUTY_CYCLE_MIN;
	}

	TIM1->CCR4 = (*duty_cycle);
	TIM8->CCR3 = (*duty_cycle);
	TIM2->CCR1 = (*duty_cycle);
	TIM5->CCR1 = (*duty_cycle);
}

/* Voltage Control for closed loop - PI controller with anti-windup mechanism
 * First 7 lines of code calculate vref which is the biggest of the values that come from the
 * potentiometer and the keyboard
 */
void voltage_control(float v_out_meas, float *duty_cycle , float *I , float duty_pot , float v_ref_pot, float *v_ref_user){
	float vref = 0;
	if ((*v_ref_user) >= v_ref_pot){
		vref = (*v_ref_user);
	}
	else if ((*v_ref_user) < v_ref_pot){
		vref = v_ref_pot;
	}
	float error = vref - v_out_meas;
	float P = KP * error;
	float New_I = *I + KI * error * ADC2_PERIOD;

	(*duty_cycle) = P + New_I;

	if (*duty_cycle > DUTY_CYCLE_MAX){
		*duty_cycle = DUTY_CYCLE_MAX;
		New_I = *I;
	}
	if (*duty_cycle < DUTY_CYCLE_MIN){
		*duty_cycle = DUTY_CYCLE_MIN;
		New_I = *I;
	}

	*I = New_I;

	TIM1->CCR4 = (*duty_cycle);
	TIM8->CCR3 = (*duty_cycle);
	TIM2->CCR1 = (*duty_cycle);
	TIM5->CCR1 = (*duty_cycle);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
